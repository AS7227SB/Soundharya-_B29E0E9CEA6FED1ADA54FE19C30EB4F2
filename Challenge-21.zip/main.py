class BankAccount:
  def__init__(self,account _number, account _holder_name,inital_balance=0.0):
  self.__account_number=account _number
  self.__account_holder_name=account _holder_name
  self.__account_balance=inital_balance
  def deposit (self,amount):
    if amount>0:
      self.__account_balance+=amount
      print ("Deposited ₹{}.New balance:₹{}."format (amount,self.__account_balance))
    else:
      print ("Invalid deposit amount.")
      def withdraw (self, amount):
        if amount >0 and amount <=self
        .__account_balance:
        self.__account_balance_=amount
         print("withdraw               ₹{}". New withdraw                ₹{}".format (amount,self.__account_balance))
              
               else:
               print ("Invalid withdraw amount or insufficient balance")
               def display_balance(self):
               print("Account balance for {}(Account#{}):₹{}". format self.__amount_holder_name,self.__account_balance))
               account=BankAccount(account_number="123456789", account _holder_name="Hari", initial balance=5000.0)
               account.display_balance()
account . deposit (500.0)
account . withdraw (200.0)
account.withdraw(2000.0)
account . display _balance()